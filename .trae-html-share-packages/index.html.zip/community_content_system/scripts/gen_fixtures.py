"""生成 r/learnprogramming 的 mock fixture。

schema 与 Reddit API 真实响应逐字段一致(Listing{kind,data{children[],after}})。
FileAdapter 读这些文件,输出与 RedditAdapter 完全相同的 DTO。
"""

import json
import os
import random
import time

FIXTURE_ROOT = os.path.join(os.path.dirname(__file__), "..", "fixtures", "learnprogramming")
os.makedirs(os.path.join(FIXTURE_ROOT, "posts"), exist_ok=True)

random.seed(42)
now = time.time()

# —— 社区元信息 —— #
about = {
    "kind": "t5",
    "data": {
        "display_name": "learnprogramming",
        "subscribers": 3500000,
        "created_utc": 1292251200,
        "subreddit_type": "public",
        "description": "A subreddit for all questions related to programming in any language.",
        "public_description": "Ask questions about programming.",
    },
}

# —— 社区规则 —— #
rules = {
    "rules": [
        {"short_name": "No advertising/self-promotion", "description": "Do not post links to your own content for promotional purposes. This includes blogs, YouTube channels, courses, and products. Read the self-promotion rules before posting.", "priority": 1},
        {"short_name": "No complete solutions", "description": "Do not ask for or post complete solutions. Ask for guidance, not the answer.", "priority": 2},
        {"short_name": "Be civil and respectful", "description": "Treat others with respect. No harassment or insults.", "priority": 3},
        {"short_name": "Use clear titles", "description": "Make your title descriptive. 'Help' is not a good title.", "priority": 4},
        {"short_name": "No off-topic posts", "description": "Posts must be related to learning programming. Job posts belong in r/cscareerquestions.", "priority": 5},
    ],
    "description": {"rules_reason": "These rules help keep the community focused on learning."},
}

# —— 帖子生成 —— #
POST_TEMPLATES = [
    # 高表现:经验型 + 具体问题 + 解决过程
    {
        "title": "After 3 months of struggling, I finally understood pointers in C. Here's what clicked.",
        "selftext": "I kept hitting a wall with pointers. Every tutorial showed memory diagrams but never explained WHY you need a pointer to a pointer. What finally clicked was realizing it's about ownership: when you pass &x to a function, you're saying 'this function can change what x points to.'\n\nThe exercise that made it real: write a function that swaps two integers. Without pointers it's impossible; with pointers you see exactly why indirection matters.\n\nFor anyone struggling: draw boxes. Seriously. Paper and pencil. Draw what's at each address before and after each line of code.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Discussion", "ups_base": 850, "comments_base": 120,
        "topic": "pointers", "scenario": "learning_struggle", "structure": "experience",
        "product_visibility": "none", "search_value": "mid",
    },
    {
        "title": "How I went from zero to my first junior dev job in 14 months (no CS degree)",
        "selftext": "Background: 26, working retail, decided to learn to code. Here's what actually mattered and what didn't.\n\nWhat mattered:\n1. Building projects instead of tutorial-hopping. I built a CLI budget tracker first, then a Flask blog, then a React todo with auth.\n2. Actually reading other people's code on GitHub. I'd clone a repo, break it, fix it.\n3. Getting rejected 47 times before the first yes.\n\nWhat didn't matter:\n- Bootcamp certificate (nobody asked)\n- Leetcode grinding (only 2 interviews tested algorithms)\n- Knowing 5 frameworks (they wanted depth in one)\n\nThe job: junior Python/Flask role. They asked me to debug a broken endpoint during the interview. I'd done that exact thing 100 times on my own projects.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Success Story", "ups_base": 2100, "comments_base": 280,
        "topic": "career_transition", "scenario": "job_search", "structure": "experience",
        "product_visibility": "none", "search_value": "high",
    },
    {
        "title": "I kept getting stuck on recursion until I tried this one approach",
        "selftext": "Everyone says 'think of the base case' but that never worked for me. What worked: writing the iterative version first, then noticing the pattern, then converting.\n\nExample with factorial:\n```python\n# Iterative\ndef fact(n):\n    result = 1\n    for i in range(1, n+1):\n        result *= i\n    return result\n\n# Recursive — notice result accumulates the same way\ndef fact(n):\n    if n <= 1: return 1\n    return n * fact(n-1)\n```\n\nThe key insight: recursion is just a loop where the 'state' (result) is implicitly passed via the call stack instead of an explicit variable.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Discussion", "ups_base": 1200, "comments_base": 95,
        "topic": "recursion", "scenario": "learning_struggle", "structure": "experience",
        "product_visibility": "none", "search_value": "high",
    },
    # 中表现:问题型 + 资源型
    {
        "title": "What's the difference between == and is in Python? When do I use which?",
        "selftext": "I keep mixing these up. From what I understand:\n\n`==` checks if values are equal\n`is` checks if they're the same object in memory\n\nBut when does it actually matter? The only case I've seen is checking `if x is None`. Are there others?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Question", "ups_base": 340, "comments_base": 60,
        "topic": "python_basics", "scenario": "concept_confusion", "structure": "question",
        "product_visibility": "none", "search_value": "high",
    },
    {
        "title": "Best resources for learning data structures in 2024?",
        "selftext": "I know basic Python and want to learn data structures properly. Not just 'memorize what a stack is' but actually implement them and understand trade-offs.\n\nI've looked at LeetCode but it feels like it's testing memorization. Any book/course that explains the WHY behind each structure?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Question", "ups_base": 220, "comments_base": 45,
        "topic": "resources", "scenario": "self_study", "structure": "question",
        "product_visibility": "subtle", "search_value": "high",
    },
    {
        "title": "Is it normal to forget syntax after switching languages?",
        "selftext": "I learned Python first, then tried Go. I keep writing `func` as `def` and forgetting semicolons in JS. Does this get better or am I just not cut out for multiple languages?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Question", "ups_base": 180, "comments_base": 40,
        "topic": "language_switching", "scenario": "learning_struggle", "structure": "question",
        "product_visibility": "none", "search_value": "mid",
    },
    # 低表现:模糊标题 / 过于宽泛 / 略带广告感
    {
        "title": "Help with Python",
        "selftext": "I'm stuck. Can someone help?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": None, "ups_base": 5, "comments_base": 8,
        "topic": "unspecified", "scenario": "unspecified", "structure": "vague",
        "product_visibility": "none", "search_value": "low",
    },
    {
        "title": "Check out my new course on learning to code fast!",
        "selftext": "I just launched a course that teaches you Python in 7 days. Use code LEARN20 for 20% off. Link in bio. This is the fastest way to become a developer.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": None, "ups_base": -15, "comments_base": 3,
        "topic": "promotion", "scenario": "promotion", "structure": "promotional",
        "product_visibility": "explicit", "search_value": "low",
    },
    {
        "title": "How do I learn programming?",
        "selftext": "I want to learn programming. Where do I start? Any tips?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": None, "ups_base": 12, "comments_base": 15,
        "topic": "getting_started", "scenario": "getting_started", "structure": "vague",
        "product_visibility": "none", "search_value": "low",
    },
    # 图片帖(高表现)
    {
        "title": "When you finally fix a bug after 4 hours and it was a missing semicolon",
        "selftext": "",
        "is_self": False, "post_hint": "image", "domain": "i.redd.it",
        "url": "https://i.redd.it/example_meme.jpg",
        "flair": "Meme", "ups_base": 3400, "comments_base": 150,
        "topic": "debugging", "scenario": "relatable", "structure": "meme",
        "product_visibility": "none", "search_value": "low",
    },
    # 链接帖(中表现)
    {
        "title": "Stack Overflow's 2024 survey shows Python overtook JavaScript in new questions",
        "selftext": "",
        "is_self": False, "post_hint": "link", "domain": "stackoverflow.blog",
        "url": "https://stackoverflow.blog/example",
        "flair": "News", "ups_base": 450, "comments_base": 70,
        "topic": "industry_trends", "scenario": "industry", "structure": "link_share",
        "product_visibility": "none", "search_value": "mid",
    },
    {
        "title": "Why does my for loop run twice?",
        "selftext": "```python\nfor i in range(5):\n    print(i)\n    i = i + 1\n```\nIt prints 0 1 2 3 4 not 0 2 4. Why?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Question", "ups_base": 95, "comments_base": 25,
        "topic": "loop_mechanics", "scenario": "concept_confusion", "structure": "question",
        "product_visibility": "none", "search_value": "high",
    },
    # —— 扩展模板(凑满 30 帖,覆盖更多 topic/scenario/structure) —— #
    # 高表现:经验型
    {
        "title": "I spent 6 months grinding LeetCode and here's what I'd do differently",
        "selftext": "I did 400 LeetCode problems. Got my first FAANG offer last week. But honestly, half that time was wasted.\n\nWhat I'd do differently:\n1. Stop doing easy problems after week 2. Most easies teach you nothing new.\n2. Focus on patterns not problems. Two-pointer, sliding window, BFS/DFS — master the pattern and you can solve 50 problems.\n3. Don't memorize. I memorized solutions and froze when the interviewer changed one variable.\n\nWhat actually worked: doing 30 mediums well, explaining each out loud to an empty room. The explaining part was key — it forced me to understand not just recall.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Success Story", "ups_base": 1800, "comments_base": 210,
        "topic": "interview_prep", "scenario": "job_search", "structure": "experience",
        "product_visibility": "none", "search_value": "high",
    },
    {
        "title": "How I built my first real project (not a tutorial) and what I learned about scope",
        "selftext": "Tutorial hell is real. I did 20 tutorials and couldn't build anything from scratch. The fix was simple but painful: pick ONE project, scope it tiny, and refuse to add features until the core works.\n\nMy project: a CLI weather app. Just fetch JSON from an API and print it. That's it. No GUI, no favorites, no caching.\n\nWhat I learned:\n1. Scope creep kills motivation. I kept wanting to add 'just one more feature'.\n2. Reading error messages slowly is a skill. I used to skim and Google immediately. Now I read the whole message first.\n3. Git commits as checkpoints. Commit after each tiny working piece.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Discussion", "ups_base": 1450, "comments_base": 175,
        "topic": "project_building", "scenario": "personal_experience", "structure": "experience",
        "product_visibility": "none", "search_value": "high",
    },
    {
        "title": "After 8 months self-taught, I finally understand what 'object-oriented' actually means",
        "selftext": "I could write classes. I could make methods. But I never understood WHY until I tried to model a deck of cards.\n\nThe breakthrough: objects are about bundling state with the behavior that changes that state. My Card class had a suit and rank. My Deck class had a list of cards and methods to shuffle/deal. The Deck didn't reach into Card's internals — it asked the Card questions.\n\nBefore this, I'd put everything in one function. The moment I split Card and Deck, encapsulation clicked. It's not about 'modeling the real world' — it's about grouping related state and controlling who can change it.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Discussion", "ups_base": 1100, "comments_base": 130,
        "topic": "oop", "scenario": "learning_struggle", "structure": "experience",
        "product_visibility": "none", "search_value": "mid",
    },
    # 中表现:问题型 + 资源型
    {
        "title": "When should I use a list vs a tuple vs a set in Python?",
        "selftext": "I always default to lists because they're familiar, but I know tuples and sets exist for reasons. Can someone give me a simple rule of thumb?\n\nFrom what I gather:\n- List: ordered, mutable, allows duplicates\n- Tuple: ordered, immutable, allows duplicates\n- Set: unordered, mutable, no duplicates\n\nBut when does 'immutable' actually matter in practice? And is the set's O(1) lookup worth it for small collections?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Question", "ups_base": 410, "comments_base": 55,
        "topic": "python_basics", "scenario": "concept_confusion", "structure": "question",
        "product_visibility": "none", "search_value": "high",
    },
    {
        "title": "How do you stay motivated when a project gets hard?",
        "selftext": "I start projects excited. Two weeks in, I hit a bug I can't solve and abandon it. I've got 15 half-finished repos. How do people push through the boring/frustrating middle part?\n\nIt's not about discipline — I genuinely want to finish things. It's that when I'm stuck for 3 days, the motivation just evaporates.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Question", "ups_base": 380, "comments_base": 90,
        "topic": "motivation", "scenario": "learning_struggle", "structure": "question",
        "product_visibility": "none", "search_value": "mid",
    },
    {
        "title": "What's the best way to learn Git for someone who only knows add/commit/push?",
        "selftext": "I've used Git for a year but only the basics. When something goes wrong — merge conflicts, detached HEAD, accidental force push — I panic and delete the repo. \n\nWhat's a good way to actually learn Git internals so I'm not terrified of it? Interactive tutorial? A specific book? I tried reading Pro Git but it felt too dense.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Question", "ups_base": 290, "comments_base": 48,
        "topic": "git", "scenario": "self_study", "structure": "question",
        "product_visibility": "none", "search_value": "high",
    },
    {
        "title": "I'm 35 and starting to learn programming. Is it actually too late?",
        "selftext": "Everyone says it's never too late but most success stories I read are people in their early 20s. I have a family and a full-time job. I can dedicate maybe 10 hours a week.\n\nIs 10 hours/week enough to become employable in 2-3 years? Or am I setting myself up for disappointment? Honest answers please, not motivational quotes.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Question", "ups_base": 520, "comments_base": 140,
        "topic": "career_transition", "scenario": "personal_experience", "structure": "question",
        "product_visibility": "none", "search_value": "mid",
    },
    {
        "title": "Can someone explain async/await like I'm five?",
        "selftext": "I've read the Python docs on asyncio five times. I understand the syntax but not the concept. Why is `await` special? What's actually happening when code 'waits'?\n\nThe callback/Promise explanations just make it worse. Is there a physical-world analogy that actually works?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Question", "ups_base": 260, "comments_base": 50,
        "topic": "async", "scenario": "concept_confusion", "structure": "question",
        "product_visibility": "none", "search_value": "mid",
    },
    # 低表现:模糊 / 宽泛 / 广告感
    {
        "title": "Stuck",
        "selftext": "Help",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": None, "ups_base": -2, "comments_base": 4,
        "topic": "unspecified", "scenario": "unspecified", "structure": "vague",
        "product_visibility": "none", "search_value": "low",
    },
    {
        "title": "My new app makes learning Python 10x faster! Free beta access inside",
        "selftext": "I built an AI-powered Python tutor that adapts to your learning speed. Sign up for the free beta at myapp.example.com. First 100 users get lifetime premium. Use promo code REDDIT10. This will replace traditional courses.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": None, "ups_base": -25, "comments_base": 2,
        "topic": "promotion", "scenario": "promotion", "structure": "promotional",
        "product_visibility": "promotional", "search_value": "low",
    },
    {
        "title": "Question about code",
        "selftext": "I have a question about my code. It doesn't work. What's wrong?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": None, "ups_base": 3, "comments_base": 6,
        "topic": "unspecified", "scenario": "unspecified", "structure": "vague",
        "product_visibility": "none", "search_value": "low",
    },
    # 中表现:讨论型 + 资源分享
    {
        "title": "The underrated skill that made me 10x faster: reading stack traces",
        "selftext": "For my first year I'd see a traceback and immediately Google the error. Now I read the whole thing top to bottom first. \n\nThe structure of a Python traceback: the LAST line is the error type, the lines above show the call chain that led there. The file:line tells you exactly where.\n\nExample: `KeyError: 'user_id'` doesn't mean 'something about user_id is wrong'. It means a dict was accessed with key 'user_id' and that key didn't exist. The traceback tells you WHICH dict and WHICH line. Read it.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Discussion", "ups_base": 670, "comments_base": 85,
        "topic": "debugging", "scenario": "personal_experience", "structure": "experience",
        "product_visibility": "none", "search_value": "high",
    },
    {
        "title": "What's your honest take on coding bootcamps in 2024?",
        "selftext": "Considering a 16-week bootcamp. Cost is $14k. I've done some freeCodeCamp and enjoyed it but feel I need structure and accountability.\n\nFor those who did bootcamps: did the network/structure justify the cost? Or could a disciplined self-taught route with a mentor have worked as well? No bootcamp sales pitches please.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Discussion", "ups_base": 350, "comments_base": 120,
        "topic": "bootcamps", "scenario": "recommendation_request", "structure": "question",
        "product_visibility": "none", "search_value": "mid",
    },
    {
        "title": "How to stop copy-pasting code I don't understand",
        "selftext": "I follow tutorials and end up with working code I didn't write. It runs but I couldn't recreate it. Is this normal at first or am I sabotaging my learning?\n\nWhat's a system to make sure I actually understand what I paste? Type it out? Comment each line? Rewrite it from memory the next day?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Question", "ups_base": 430, "comments_base": 65,
        "topic": "learning_method", "scenario": "learning_struggle", "structure": "question",
        "product_visibility": "none", "search_value": "high",
    },
    # 高表现:经验型(带 code)
    {
        "title": "I refactored a 200-line function into 5 small ones — here's the before/after",
        "selftext": "Inherited a legacy function that did: fetch data, transform it, validate it, write to DB, send email. All in one 200-line function.\n\nBefore: couldn't test anything without a DB connection. One bug in the email part broke the whole thing.\n\nAfter:\n```python\ndef fetch_orders(date): ...\ndef transform_records(raw): ...\ndef validate(records): ...\ndef persist(records): ...\ndef notify(records): ...\n```\n\nEach function testable independently. The email bug? Doesn't affect DB write. The transformation bug? Caught in `validate` before it hits DB. \n\nThe principle: one function, one reason to change.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Discussion", "ups_base": 980, "comments_base": 110,
        "topic": "refactoring", "scenario": "personal_experience", "structure": "experience",
        "product_visibility": "none", "search_value": "high",
    },
    {
        "title": "The moment SQL finally made sense to me — it's just filters and joins",
        "selftext": "I avoided databases for months. SQL looked like alien text. Then someone reframed it: a SELECT is just 'give me these columns', WHERE is 'filter to these rows', JOIN is 'glue two tables on a shared column'.\n\nThe order of operations isn't the order you write it:\n1. FROM (pick the table(s))\n2. JOIN (glue them)\n3. WHERE (filter rows)\n4. SELECT (pick columns)\n5. ORDER BY (sort)\n\nOnce I knew the execution order, complex queries became readable. `SELECT name FROM users JOIN orders ON users.id = orders.user_id WHERE orders.total > 100` is just: glue users+orders, keep rows where total>100, show me the name.",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": "Discussion", "ups_base": 1020, "comments_base": 95,
        "topic": "sql", "scenario": "learning_struggle", "structure": "experience",
        "product_visibility": "none", "search_value": "high",
    },
    # 低表现:模糊 + 重复提问
    {
        "title": "Best language to learn?",
        "selftext": "What's the best programming language to learn first? I've heard Python and JavaScript. Which one?",
        "is_self": True, "post_hint": None, "domain": "self.learnprogramming",
        "flair": None, "ups_base": 8, "comments_base": 12,
        "topic": "getting_started", "scenario": "recommendation_request", "structure": "vague",
        "product_visibility": "none", "search_value": "low",
    },
    # 中表现:图片帖
    {
        "title": "My desk setup for my first dev job — 3 years from where I started",
        "selftext": "",
        "is_self": False, "post_hint": "image", "domain": "i.redd.it",
        "url": "https://i.redd.it/example_desk.jpg",
        "flair": "Success Story", "ups_base": 470, "comments_base": 60,
        "topic": "career_transition", "scenario": "personal_experience", "structure": "image_share",
        "product_visibility": "none", "search_value": "low",
    },
    # 中表现:链接帖
    {
        "title": "GitHub's 2024 Octoverse report: Python remains #1, TypeScript climbing fast",
        "selftext": "",
        "is_self": False, "post_hint": "link", "domain": "github.blog",
        "url": "https://github.blog/example",
        "flair": "News", "ups_base": 320, "comments_base": 42,
        "topic": "industry_trends", "scenario": "industry", "structure": "link_share",
        "product_visibility": "none", "search_value": "mid",
    },
]

# 评论模板
COMMENT_TEMPLATES = [
    ("Great explanation, the box-drawing tip actually helped me too.", 45, 0),
    ("This is why I love this sub. Actual explanations, not just 'google it'.", 32, 0),
    ("Can you elaborate on ownership? I think I get it but not 100%.", 12, 0),
    ("Tried the swap exercise. Mind blown. Why didn't my professor explain it this way?", 28, 0),
    ("This is gold. Saving for later.", 8, 0),
    ("Hot take: pointers are easy if you understand memory. The problem is most courses skip memory.", 15, 0),
    ("Your iterative-to-recursive trick is underrated. Teaching it this way should be standard.", 22, 0),
    ("Same here. Took me 6 months and it was a drawing on paper that did it.", 18, 0),
    ("`is None` is basically the only case you need `is` in Python. Everything else, use `==`.", 35, 0),
    ("Also matters for small integers due to interning: `a = 256; b = 256; a is b` is True, but 257 is False. CPython caches -5 to 256.", 41, 0),
    ("Have you looked at 'Grokking Algorithms'? It explains the why behind each structure with visual examples.", 19, 0),
    ("Totally normal. After 3 languages you stop noticing. Your brain compartmentalizes.", 14, 0),
    ("You need to be way more specific. What are you stuck ON? What have you tried? What's the error?", -5, 0),
    ("Read the wiki. This question gets asked every week.", 3, 0),
    ("Reported for self-promotion. Read rule 1.", 2, 0),
    ("This is a known FAQ: https://wiki.learnprogramming/GettingStarted", 7, 0),
    ("Memes like this are why I keep coming back lol", 67, 0),
    ("Not surprising. Python's growth has been obvious for years.", 11, 0),
    ("Because `range` produces values 0-4 and reassigning `i` inside the loop doesn't change what range yields next. The loop variable is reassigned at the top of each iteration.", 38, 0),
    ("Same confusion when I started. The loop doesn't read your modified `i`.", 9, 0),
    # —— 扩展评论模板 —— #
    ("The 'patterns not problems' advice is gold. Wish someone told me this 200 problems ago.", 56, 0),
    ("Disagree on stopping easies. Easies built my confidence when I was starting out.", -3, 0),
    ("Explaining out loud works. I started doing this and caught so many holes in my own understanding.", 28, 0),
    ("Scope creep is real. I abandoned my last 3 projects because of it. Going to try the 'one feature at a time' rule.", 22, 0),
    ("CLI weather app — this is EXACTLY the kind of project size beginners should start with.", 19, 0),
    ("Git commits as checkpoints is underrated advice. Saved me many times when I broke things.", 14, 0),
    ("The deck of cards example is perfect. I'm going to try this with my students.", 31, 0),
    ("Encapsulation finally clicked for me when I realized it's about 'who can change this state'.", 18, 0),
    ("Use a tuple when you want to signal 'this shouldn't change'. Like coordinates or config.", 33, 0),
    ("Sets are great for deduplication. `list(set(my_list))` to remove duplicates.", 25, 0),
    ("For small collections, the lookup speed difference is negligible. Use whatever is clearer.", 12, 0),
    ("Motivation is a myth. Build a habit instead. 30 minutes daily beats 5 hours on weekends.", 47, 0),
    ("I keep a 'lessons learned' doc per project. When I'm stuck I read it. Reminds me I've solved worse.", 16, 0),
    ("Take a break. Seriously. Walk away for an hour. The bug often jumps out when you come back.", 39, 0),
    ("Pro Git is dense but chapter 1-3 are gold. Skip around — you don't need to read linearly.", 21, 0),
    ("Learn `git reflog`. It saved me from a force-push disaster once. It's a time machine.", 35, 0),
    ("I'm 38 and just got my first dev job last month. 18 months of 10 hrs/week. It's doable.", 58, 0),
    ("The honest answer: 10 hrs/week means 3-4 years, not 2. But it's doable. Consistency > hours.", 29, 0),
    ("Async clicked when I imagined a restaurant: waiters don't stand by the kitchen, they take new orders while food cooks.", 44, 0),
    ("`await` literally means 'pause this function until the result is ready, let other code run meanwhile'.", 31, 0),
    ("Your post needs way more detail. What's the error? What have you tried? What's your code?", -2, 0),
    ("Downvoted for the app promo. We have rules against self-promo here.", -8, 0),
    ("Reported. Read rule 1 — no advertising in this sub.", 5, 0),
    ("Reading stack traces is THE skill. I wasted hours Googling before I learned to read them.", 52, 0),
    ("The file:line in a traceback is the most important part. Start there, not the error type.", 23, 0),
    ("Bootcamp grad here. The network was worth it for me. The curriculum was okay. YMMV.", 27, 0),
    ("Self-taught with a mentor > bootcamp, IMO. Mentors answer YOUR specific confusion.", 18, 0),
    ("Type it out by hand, then close the tutorial and try to rewrite it. That's what worked for me.", 36, 0),
    ("Commenting each line is underrated. Forces you to articulate why, not just what.", 15, 0),
    ("Single responsibility principle in action. This example should be in every OOP intro.", 41, 0),
    ("Testability is the real win. Each function can be unit tested without mocking the world.", 22, 0),
    ("SQL execution order is the missing piece in every tutorial. Thanks for spelling it out.", 33, 0),
    ("I'd add: GROUP BY comes after WHERE but before HAVING. People mix that up constantly.", 17, 0),
    ("There's no 'best' language. Pick one, build something, repeat. Python is fine to start.", 24, 0),
    ("This question gets asked 5 times a week. Try searching first.", -4, 0),
    ("Nice setup! I'm 6 months into my first job too. Never going back to retail lol.", 14, 0),
    ("The sub's vibe is 'ask specific questions, show what you've tried'. Vague posts get downvoted.", 11, 0),
]


def make_post_dto(template, idx):
    post_id = f"learnprog_post_{idx:02d}"
    fullname = f"t3_{post_id}"
    created = now - random.randint(86400 * 2, 86400 * 60)  # 2-60 days ago
    ups = template["ups_base"] + random.randint(-50, 50)
    comments = template["comments_base"] + random.randint(-10, 10)
    content_form = "text"
    if template.get("post_hint") == "image":
        content_form = "image"
    elif not template.get("is_self", True):
        content_form = "link"

    return {
        "kind": "t3",
        "data": {
            "id": post_id,
            "name": fullname,
            "subreddit": "learnprogramming",
            "title": template["title"],
            "selftext": template["selftext"],
            "url": template.get("url", ""),
            "is_self": template.get("is_self", True),
            "post_hint": template.get("post_hint"),
            "domain": template.get("domain", "self.learnprogramming"),
            "link_flair_text": template.get("flair"),
            "link_flair_template_id": f"flair_{idx:02d}" if template.get("flair") else None,
            "author": f"user_{random.randint(1, 50):02d}",
            "created_utc": created,
            "permalink": f"/r/learnprogramming/comments/{post_id}/slug/",
            "ups": ups,
            "score": ups,
            "upvote_ratio": round(random.uniform(0.7, 0.98), 2),
            "num_comments": comments,
            "view_count": None,
            "is_video": template.get("post_hint") == "video",
            "poll_data": None,
            "url_overridden_by_dest": template.get("url"),
        },
    }


def make_comment_dto(post_fullname, post_subreddit, idx, depth=0, parent_id=None):
    comment_id = f"cmt_{idx:04d}"
    fullname = f"t1_{comment_id}"
    body, score, _ = COMMENT_TEMPLATES[idx % len(COMMENT_TEMPLATES)]
    return {
        "kind": "t1",
        "data": {
            "id": comment_id,
            "name": fullname,
            "link_id": post_fullname,
            "subreddit": post_subreddit,
            "author": f"user_{random.randint(1, 50):02d}",
            "body": body,
            "score": score + random.randint(-3, 3),
            "created_utc": now - random.randint(3600, 86400 * 10),
            "depth": depth,
            "parent_id": parent_id or post_fullname,
        },
    }


def make_listing(posts, sort, time_filter=None):
    children = [make_post_dto(p, i) for i, p in enumerate(posts)]
    return {
        "kind": "Listing",
        "data": {
            "children": children,
            "after": None,
            "before": None,
        },
    }


def write_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def main():
    write_json(os.path.join(FIXTURE_ROOT, "about.json"), about)
    write_json(os.path.join(FIXTURE_ROOT, "rules.json"), rules)

    # 30 帖分布(模拟 Reddit:top/hot/new 有重叠,但每个 listing 视角不同)
    sorted_by_score = sorted(POST_TEMPLATES, key=lambda p: p["ups_base"], reverse=True)
    # top:按 score 取全部(以历史最高表现为主)
    top_posts = sorted_by_score[:]  # 全部 30 帖按 score 倒序
    # hot:近期活跃,中等分数为主 + 几个高分帖
    hot_posts = sorted_by_score[2:18]  # 取中段 16 帖
    # new:按 created 时间倒序(新帖优先,模拟 new listing)
    new_posts = list(reversed(POST_TEMPLATES[-12:]))  # 最新 12 帖

    write_json(os.path.join(FIXTURE_ROOT, "top_month.json"), make_listing(top_posts, "top", "month"))
    write_json(os.path.join(FIXTURE_ROOT, "hot.json"), make_listing(hot_posts, "hot"))
    write_json(os.path.join(FIXTURE_ROOT, "new.json"), make_listing(new_posts, "new"))

    # 搜索 fixture(多主题覆盖)
    def _match(keywords):
        return [p for p in POST_TEMPLATES
                if any(kw in p["title"].lower() or kw in p["selftext"].lower() for kw in keywords)]

    write_json(os.path.join(FIXTURE_ROOT, "search_python.json"),
               make_listing(_match(["python"]), "relevance"))
    write_json(os.path.join(FIXTURE_ROOT, "search_recursion.json"),
               make_listing(_match(["recursion"]), "relevance"))
    write_json(os.path.join(FIXTURE_ROOT, "search_pointers.json"),
               make_listing(_match(["pointer"]), "relevance"))
    write_json(os.path.join(FIXTURE_ROOT, "search_career.json"),
               make_listing(_match(["job", "career", "bootcamp"]), "relevance"))
    write_json(os.path.join(FIXTURE_ROOT, "search_motivation.json"),
               make_listing(_match(["motivation", "stuck", "give up"]), "relevance"))

    # 为代表性帖子生成评论(fixture:posts/<id>.json)
    # 选 6 个代表(高/中/低各 2),保证评论深采有足够样本
    representative_indices = [
        POST_TEMPLATES.index(sorted_by_score[0]),   # 最高(经验型)
        POST_TEMPLATES.index(sorted_by_score[2]),   # 高表现
        POST_TEMPLATES.index(sorted_by_score[8]),   # 中表现
        POST_TEMPLATES.index(sorted_by_score[14]),  # 中表现
        POST_TEMPLATES.index(sorted_by_score[-2]),  # 低表现(模糊)
        POST_TEMPLATES.index(sorted_by_score[-1]),  # 最低(广告感)
    ]
    for i, idx in enumerate(representative_indices):
        tmpl = POST_TEMPLATES[idx]
        post_dto = make_post_dto(tmpl, idx)
        post_id = post_dto["data"]["id"]
        post_fullname = post_dto["data"]["name"]
        sub = post_dto["data"]["subreddit"]

        # 生成 8-15 条评论
        n_comments = random.randint(8, 15)
        comments = []
        for j in range(n_comments):
            c = make_comment_dto(post_fullname, sub, j + i * 200, depth=0)
            comments.append(c)
            # 随机加 1-2 条回复
            if random.random() < 0.4:
                reply = make_comment_dto(post_fullname, sub, j + i * 200 + 100, depth=1, parent_id=c["data"]["name"])
                comments.append(reply)

        # Reddit API 格式:[{post listing}, {comment listing}]
        post_listing = {"kind": "Listing", "data": {"children": [post_dto], "after": None, "before": None}}
        comment_listing = {"kind": "Listing", "data": {"children": comments, "after": None, "before": None}}
        write_json(os.path.join(FIXTURE_ROOT, "posts", f"{post_id}.json"), [post_listing, comment_listing])

    print(f"fixture 生成完成: {FIXTURE_ROOT}")
    print(f"  about.json / rules.json")
    print(f"  top_month.json ({len(top_posts)} posts)")
    print(f"  hot.json ({len(hot_posts)} posts)")
    print(f"  new.json ({len(new_posts)} posts)")
    print(f"  search: python/recursion/pointers/career/motivation")
    print(f"  posts/ ({len(representative_indices)} posts with comments)")
    print(f"  total templates: {len(POST_TEMPLATES)}")


if __name__ == "__main__":
    main()
